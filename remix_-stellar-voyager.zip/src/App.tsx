/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useRef, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Radio, Telescope, Rocket, Search, X } from 'lucide-react';
import { celestialBodies, CelestialBody } from './types';
import { CelestialModal } from './components/CelestialModal';

export default function App() {
  const [activeBody, setActiveBody] = useState<CelestialBody>(celestialBodies[0]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [imageError, setImageError] = useState(false);

  const [activeFilter, setActiveFilter] = useState<CelestialBody['type'] | 'all'>('all');
  
  const filteredBodies = useMemo(() => {
    return celestialBodies.filter(b => {
      const matchesFilter = activeFilter === 'all' || b.type === activeFilter;
      const matchesSearch = b.name.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesFilter && matchesSearch;
    });
  }, [activeFilter, searchQuery]);

  return (
    <div className="w-full h-screen bg-[#02040a] text-slate-100 font-sans overflow-hidden relative flex selection:bg-blue-500/30">
      <div className="stars-bg" />
      <div className="atmospheric-glow-orange" />
      <div className="atmospheric-glow-blue" />
      <div className="star-field" />

      {/* Header/Nav */}
      <nav className="absolute top-0 left-0 w-full h-20 px-8 md:px-12 flex items-center justify-between z-50 pointer-events-none">
        <div className="flex items-center gap-3 pointer-events-auto cursor-default">
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-blue-500 to-indigo-300 shadow-[0_0_15px_rgba(59,130,246,0.5)] flex items-center justify-center">
            <Telescope className="w-4 h-4 text-white" />
          </div>
          <span className="text-xl font-bold tracking-widest uppercase font-display">Stellar.OS</span>
        </div>

        {/* Global Search */}
        <div className="absolute left-1/2 -translate-x-1/2 w-64 md:w-96 flex items-center bg-white/5 border border-white/10 rounded-full px-4 py-2 pointer-events-auto backdrop-blur-md focus-within:border-blue-500/50 transition-colors">
          <Search className="w-3.5 h-3.5 text-white/30 mr-3" />
          <input 
            type="text" 
            placeholder="Search celestial bodies..." 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="bg-transparent border-none outline-none text-[10px] tracking-widest uppercase text-white placeholder:text-white/20 w-full"
          />
          {searchQuery && (
            <button onClick={() => setSearchQuery('')} className="p-1 hover:text-white transition-colors">
              <X className="w-3 h-3" />
            </button>
          )}
        </div>

        <div className="hidden md:flex gap-6 text-[9px] font-bold tracking-[0.3em] uppercase opacity-40 pointer-events-auto">
          {(['all', 'star', 'planet', 'galaxy', 'discovered'] as const).map(f => (
            <button 
              key={f}
              onClick={() => setActiveFilter(f)}
              className={`hover:text-white transition-colors cursor-pointer ${activeFilter === f ? 'text-white underline decoration-blue-500/50 underline-offset-8' : ''}`}
            >
              {f === 'discovered' ? 'Discovered' : f}
            </button>
          ))}
        </div>
      </nav>

      {/* Left Sidebar */}
      <aside className="w-20 md:w-80 h-full bg-white/5 backdrop-blur-xl border-r border-white/10 pt-24 pb-12 flex flex-col z-40 relative">
        <div className="px-6 mb-4 hidden md:block">
          <p className="text-[10px] uppercase tracking-[0.2em] text-slate-400">Celestial Catalog</p>
        </div>
        
        <div className="flex-1 overflow-y-auto custom-scrollbar px-3 md:px-6 flex flex-col gap-2">
          {filteredBodies.map((body) => (
            <button
              key={body.id}
              onClick={() => setActiveBody(body)}
              className={`flex items-center gap-4 p-3 md:p-4 rounded-2xl transition-all group ${
                activeBody.id === body.id 
                  ? 'bg-white/10 ring-1 ring-white/20' 
                  : 'hover:bg-white/5'
              }`}
            >
              <div 
                className={`w-8 h-8 rounded-full flex-shrink-0 shadow-lg border border-white/10 ${
                  activeBody.id === body.id ? 'scale-110 shadow-[0_0_15px_rgba(255,255,255,0.3)]' : 'opacity-40 group-hover:opacity-70'
                }`}
                style={{ background: body.color }}
              />
              <span className={`hidden md:block text-sm tracking-wide transition-transform ${
                activeBody.id === body.id ? 'font-bold translate-x-1' : 'opacity-50 group-hover:opacity-100 group-hover:translate-x-1'
              }`}>
                {body.name}
              </span>
            </button>
          ))}
        </div>

        <div className="mt-8 px-6 hidden md:block">
          <div className="flex items-center gap-3 opacity-30 text-[10px] uppercase font-bold tracking-widest">
            <Radio className="w-3 h-3 animate-pulse" />
            Live Telemetry
          </div>
        </div>
      </aside>

      {/* Main Area */}
      <main className="flex-1 h-full pt-28 px-8 md:px-16 relative">
        {/* Large Planet Display (Behind Text) */}
        <div className="absolute top-1/2 left-1/2 md:left-2/3 -translate-x-1/2 -translate-y-1/2 w-[350px] h-[350px] md:w-[550px] md:h-[550px] pointer-events-none select-none">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeBody.id}
              initial={{ opacity: 0, scale: 0.9, rotate: -5 }}
              animate={{ opacity: 1, scale: 1, rotate: 0 }}
              exit={{ opacity: 0, scale: 1.05, rotate: 5 }}
              transition={{ duration: 0.6, ease: "easeOut" }}
              onAnimationStart={() => setImageError(false)}
              className="relative w-full h-full flex items-center justify-center"
            >
              <div className="relative w-full h-full flex items-center justify-center">
                {!imageError ? (
                  <img 
                    src={activeBody.image} 
                    alt={activeBody.name}
                    referrerPolicy="no-referrer"
                    onError={() => setImageError(true)}
                    className="w-full h-full object-cover rounded-full shadow-2xl brightness-110 contrast-110"
                    style={{ 
                      boxShadow: `0 0 100px ${activeBody.color}33`,
                      filter: "drop-shadow(0 0 10px rgba(0,0,0,0.5))"
                    }}
                  />
                ) : (
                  <div 
                    className="w-full h-full rounded-full flex flex-col items-center justify-center text-center p-8 bg-black/40 border border-white/5 backdrop-blur-sm shadow-2xl font-display"
                    style={{ boxShadow: `0 0 100px ${activeBody.color}22` }}
                  >
                    <span className="text-[10px] tracking-[0.4em] uppercase opacity-40 mb-2">Observation Data</span>
                    <span className="text-[12px] font-bold tracking-widest uppercase opacity-80 text-white/60 leading-tight">Visual Interface<br/>Not Available</span>
                  </div>
                )}
                {/* Spherical depth overlays - softened for better texture visibility */}
                <div className="absolute inset-0 rounded-full pointer-events-none shadow-[inset_-25px_-25px_60px_rgba(0,0,0,0.6),inset_15px_15px_40px_rgba(255,255,255,0.15)] bg-gradient-to-tr from-black/10 to-transparent" />
                
                {/* Rings for Saturn/Uranus */}
                {(activeBody.id === 'saturn' || activeBody.id === 'uranus') && (
                  <div 
                    className={`absolute w-[180%] h-[40%] border-[2px] md:border-[3px] border-white/20 rounded-[50%] rotate-[20deg] blur-[1px] -z-10`}
                    style={{ 
                      borderColor: activeBody.color + '33',
                      background: `radial-gradient(ellipse at center, transparent 40%, ${activeBody.color}11 100%)`
                    }}
                  />
                )}
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Content Labels */}
        <div className="relative z-10 max-w-2xl h-full flex flex-col justify-center">
          <motion.div
            key={`info-${activeBody.id}`}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
          >
            <h2 className="text-[140px] font-black leading-none tracking-tighter opacity-5 absolute -top-16 -left-4 font-display select-none">
              {activeBody.id === 'sun' ? '00' : celestialBodies.indexOf(activeBody).toString().padStart(2, '0')}
            </h2>
            <h1 className="text-6xl md:text-9xl font-light tracking-tight mb-4 italic font-serif">
              {activeBody.name}
            </h1>
            <p className="text-lg md:text-xl text-slate-400 leading-relaxed font-light mb-8 max-w-lg">
              {activeBody.description}
            </p>

            <div className="flex gap-4 mb-12">
              <button 
                onClick={() => setIsModalOpen(true)}
                className="px-8 py-4 bg-white text-black font-bold uppercase tracking-widest text-[10px] rounded-full hover:bg-slate-200 transition-all shadow-[0_10px_30px_rgba(255,255,255,0.1)] active:scale-95"
              >
                Detailed Specs
              </button>
              <button 
                onClick={() => setIsModalOpen(true)}
                className="px-8 py-4 border border-white/20 text-white font-bold uppercase tracking-widest text-[10px] rounded-full hover:bg-white/5 transition-all backdrop-blur-md active:scale-95"
              >
                Surface Data
              </button>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-8 pt-8 border-t border-white/10 max-w-xl">
              <StatDisplay label="Rotation" value={activeBody.details.rotationPeriod} />
              <StatDisplay label="Mass" value={activeBody.details.mass.split(' ')[0]} unit={activeBody.details.mass.split(' ').slice(1).join(' ')} />
              <StatDisplay label="Temp" value={activeBody.details.temperature.split(' ')[0]} unit={activeBody.details.temperature.split(' ').slice(1).join(' ')} />
            </div>
          </motion.div>
        </div>

        {/* Discovery Drawer Preview */}
        <div className="absolute bottom-12 right-12 w-64 p-6 bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl hidden md:block">
          <div className="flex items-center justify-between mb-4">
            <span className="text-[8px] uppercase tracking-widest font-black text-white/40">Notable Fact</span>
            <div className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse"></div>
          </div>
          <p className="text-[11px] text-slate-400 leading-relaxed line-clamp-3">
            {activeBody.details.funFacts[0]}
          </p>
        </div>
      </main>

      {/* Status Bar */}
      <div className="absolute bottom-0 left-0 w-full h-8 px-12 pb-2 md:flex items-center justify-between text-[8px] tracking-[0.4em] uppercase opacity-30 z-50 pointer-events-none hidden">
        <span>Milky Way Galaxy / Solar System / Sector 04</span>
        <span>Signal Status: Verified Encrypted</span>
      </div>

      <CelestialModal 
        body={isModalOpen ? activeBody : null} 
        onClose={() => setIsModalOpen(false)} 
      />

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: rgba(255, 255, 255, 0.02);
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(255, 255, 255, 0.1);
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(255, 255, 255, 0.2);
        }
      `}</style>
    </div>
  );
}

function StatDisplay({ label, value, unit }: { label: string; value: string; unit?: string }) {
  return (
    <div className="flex flex-col gap-1">
      <span className="text-[9px] uppercase tracking-[0.2em] text-slate-500 font-bold">{label}</span>
      <span className="text-xl md:text-2xl font-light whitespace-nowrap">
        {value} {unit && <span className="text-[10px] opacity-30 uppercase font-bold">{unit}</span>}
      </span>
    </div>
  );
}
