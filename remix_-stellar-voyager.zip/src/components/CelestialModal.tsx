/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { ReactNode, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Info, Scale, Ruler, Thermometer, Orbit, Moon, Zap } from 'lucide-react';
import { CelestialBody } from '../types';

interface ModalProps {
  body: CelestialBody | null;
  onClose: () => void;
}

export function CelestialModal({ body, onClose }: ModalProps) {
  const [imageError, setImageError] = useState(false);
  if (!body) return null;

  return (
    <AnimatePresence>
      {body && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 md:p-8">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/80 backdrop-blur-md"
          />
          <motion.div
            layoutId={`card-${body.id}`}
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="relative w-full max-w-4xl max-h-[90vh] overflow-y-auto glass-morphism rounded-3xl overflow-hidden shadow-2xl"
          >
            <button
              onClick={onClose}
              className="absolute top-6 right-6 p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors z-10"
            >
              <X className="w-6 h-6" />
            </button>

            <div className="grid md:grid-cols-2 gap-8 p-8 md:p-12">
              <div className="flex flex-col items-center justify-center relative font-display">
                <div className="relative w-64 h-64 md:w-80 md:h-80">
                  {!imageError ? (
                    <motion.img
                      layoutId={`img-${body.id}`}
                      src={body.image}
                      alt={body.name}
                      referrerPolicy="no-referrer"
                      onError={() => setImageError(true)}
                      className="w-full h-full object-cover rounded-full shadow-2xl brightness-110 contrast-110"
                      style={{ 
                        boxShadow: `0 0 60px ${body.color}44`,
                      }}
                    />
                  ) : (
                    <motion.div 
                      layoutId={`img-${body.id}`}
                      className="w-full h-full rounded-full flex flex-col items-center justify-center text-center p-8 bg-black/40 border border-white/5 backdrop-blur-sm shadow-2xl"
                      style={{ boxShadow: `0 0 60px ${body.color}33` }}
                    >
                      <span className="text-[10px] tracking-[0.4em] uppercase opacity-40 mb-2">Observation Data</span>
                      <span className="text-[12px] font-bold tracking-widest uppercase opacity-80 text-white/60 leading-tight">Visual Interface<br/>Not Available</span>
                    </motion.div>
                  )}
                  <div className="absolute inset-0 rounded-full pointer-events-none shadow-[inset_-25px_-25px_50px_rgba(0,0,0,0.6),inset_15px_15px_30px_rgba(255,255,255,0.15)]" />
                </div>
                <div className="mt-8 text-center">
                  <h2 className="text-4xl md:text-6xl font-bold font-display tracking-tight" style={{ color: body.color }}>
                    {body.name}
                  </h2>
                  <p className="text-xl text-white/60 mt-2 capitalize">{body.type}</p>
                </div>
              </div>

              <div className="flex flex-col gap-8">
                <div>
                  <h3 className="text-sm font-semibold uppercase tracking-widest text-white/40 mb-4 flex items-center gap-2">
                    <Info className="w-4 h-4" /> Description
                  </h3>
                  <p className="text-lg leading-relaxed text-white/80">{body.description}</p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <StatItem icon={<Scale />} label="Mass" value={body.details.mass} />
                  <StatItem icon={<Ruler />} label="Diameter" value={body.details.diameter} />
                  <StatItem icon={<Thermometer />} label="Temp" value={body.details.temperature} />
                  <StatItem icon={<Zap />} label="Rotation" value={body.details.rotationPeriod} />
                  {body.details.orbitalPeriod && (
                    <StatItem icon={<Orbit />} label="Orbit" value={body.details.orbitalPeriod} />
                  )}
                  {body.details.moons !== undefined && (
                    <StatItem icon={<Moon />} label="Moons" value={body.details.moons.toString()} />
                  )}
                </div>

                <div>
                  <h3 className="text-sm font-semibold uppercase tracking-widest text-white/40 mb-4">Fun Facts</h3>
                  <ul className="space-y-3">
                    {body.details.funFacts.map((fact, i) => (
                      <li key={i} className="flex gap-3 text-white/70 italic text-sm md:text-base">
                        <span className="text-blue-400">•</span> {fact}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}

function StatItem({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="p-4 rounded-2xl bg-white/5 border border-white/10 hover:bg-white/10 transition-colors">
      <div className="flex items-center gap-2 text-white/40 mb-1">
        {icon}
        <span className="text-[10px] uppercase font-bold tracking-tighter">{label}</span>
      </div>
      <div className="text-sm font-semibold truncate" title={value}>{value}</div>
    </div>
  );
}
