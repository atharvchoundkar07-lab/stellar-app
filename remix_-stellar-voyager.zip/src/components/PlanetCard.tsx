/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';
import { ChevronRight } from 'lucide-react';
import { CelestialBody } from '../types';

interface CardProps {
  body: CelestialBody;
  onClick: () => void;
}

export const PlanetCard: React.FC<CardProps> = ({ body, onClick }) => {
  return (
    <motion.div
      layoutId={`card-${body.id}`}
      onClick={onClick}
      className="relative flex-none w-[280px] md:w-[350px] aspect-[4/5] rounded-[2rem] overflow-hidden cursor-pointer group glass-morphism"
      whileHover={{ y: -10 }}
      transition={{ type: 'spring', stiffness: 300, damping: 20 }}
    >
      <div className="absolute inset-0 z-0">
        <motion.img
          layoutId={`img-${body.id}`}
          src={body.image}
          alt={body.name}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent" />
      </div>

      <div className="absolute bottom-0 left-0 right-0 p-8 z-10">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col gap-1"
        >
          <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-white/50">{body.type}</span>
          <h3 className="text-3xl font-bold font-display" style={{ textShadow: `0 0 20px ${body.color}88` }}>
            {body.name}
          </h3>
          <p className="text-sm text-white/60 line-clamp-2 mt-2 font-light leading-relaxed">
            {body.description}
          </p>
          
          <button className="mt-6 flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-white hover:text-white/80 transition-colors group/btn">
            Explore Details
            <ChevronRight className="w-4 h-4 transition-transform group-hover/btn:translate-x-1" />
          </button>
        </motion.div>
      </div>

      {/* Decorative glow */}
      <div 
        className="absolute -top-1/2 -left-1/2 w-full h-full opacity-0 group-hover:opacity-20 transition-opacity blur-[100px]"
        style={{ backgroundColor: body.color }}
      />
    </motion.div>
  );
}
