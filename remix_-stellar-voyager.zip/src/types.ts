/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface CelestialBody {
  id: string;
  name: string;
  type: 'star' | 'planet' | 'galaxy' | 'discovered';
  description: string;
  details: {
    mass: string;
    diameter: string;
    distanceFromSun?: string;
    rotationPeriod: string;
    orbitalPeriod?: string;
    temperature: string;
    moons?: number;
    funFacts: string[];
  };
  image: string;
  color: string; // Theme color for glow effects
}

export const celestialBodies: CelestialBody[] = [
  {
    id: 'sun',
    name: 'The Sun',
    type: 'star',
    description: 'The heart of our solar system, the Sun is a nearly perfect sphere of hot plasma.',
    details: {
      mass: '1.989 × 10^30 kg',
      diameter: '1,392,700 km',
      rotationPeriod: '25-35 days',
      temperature: '5,500°C (Surface)',
      funFacts: [
        'The Sun contains 99.86% of the mass in the Solar System.',
        'It is about 4.6 billion years old.',
        'Light from the Sun takes 8 minutes and 20 seconds to reach Earth.'
      ]
    },
    image: 'https://images.unsplash.com/photo-1529788295308-1eace6f67388?auto=format&fit=crop&q=80&w=800',
    color: '#ffcc00'
  },
  {
    id: 'mercury',
    name: 'Mercury',
    type: 'planet',
    description: 'The smallest and innermost planet in the Solar System.',
    details: {
      mass: '3.285 × 10^23 kg',
      diameter: '4,879 km',
      distanceFromSun: '57.9 million km',
      rotationPeriod: '58.6 days',
      orbitalPeriod: '88 days',
      temperature: '-173°C to 427°C',
      moons: 0,
      funFacts: [
        'Mercury has no atmosphere.',
        'A year on Mercury is shorter than its day.',
        'It is the second densest planet.'
      ]
    },
    image: 'https://images.unsplash.com/photo-1614728894747-a83421e2b9c9?auto=format&fit=crop&q=80&w=800',
    color: '#a5a5a5'
  },
  {
    id: 'venus',
    name: 'Venus',
    type: 'planet',
    description: 'Often called Earth’s twin, Venus is the hottest planet in our solar system.',
    details: {
      mass: '4.867 × 10^24 kg',
      diameter: '12,104 km',
      distanceFromSun: '108.2 million km',
      rotationPeriod: '243 days',
      orbitalPeriod: '225 days',
      temperature: '462°C',
      moons: 0,
      funFacts: [
        'Venus rotates in the opposite direction to most planets.',
        'Its atmosphere is thick and toxic, filled with sulfuric acid.',
        'It is the second brightest object in the night sky after the Moon.'
      ]
    },
    image: 'https://images.unsplash.com/photo-1614313913007-2b4ae8ce32d6?auto=format&fit=crop&q=80&w=800',
    color: '#e3bb76'
  },
  {
    id: 'earth',
    name: 'Earth',
    type: 'planet',
    description: 'Our home planet, the only place in the universe known to harbor life.',
    details: {
      mass: '5.972 × 10^24 kg',
      diameter: '12,742 km',
      distanceFromSun: '149.6 million km',
      rotationPeriod: '24 hours',
      orbitalPeriod: '365.25 days',
      temperature: '-88°C to 58°C',
      moons: 1,
      funFacts: [
        '71% of Earth’s surface is covered by water.',
        'It is the only planet not named after a god.',
        'Earth’s atmosphere protects us from meteoroids and radiation.'
      ]
    },
    image: 'https://images.unsplash.com/photo-1614730321146-b6fa6a46bcb4?auto=format&fit=crop&q=80&w=800',
    color: '#2b82c9'
  },
  {
    id: 'mars',
    name: 'Mars',
    type: 'planet',
    description: 'The "Red Planet," home to the largest volcano in the solar system.',
    details: {
      mass: '6.39 × 10^23 kg',
      diameter: '6,779 km',
      distanceFromSun: '227.9 million km',
      rotationPeriod: '24.6 hours',
      orbitalPeriod: '687 days',
      temperature: '-153°C to 20°C',
      moons: 2,
      funFacts: [
        'Mars is home to Olympus Mons, the tallest volcano in the solar system.',
        'It has polar ice caps like Earth.',
        'Mars has the largest dust storms in the solar system.'
      ]
    },
    image: 'https://images.unsplash.com/photo-1614728894747-a83421e2b9c9?auto=format&fit=crop&q=80&w=800',
    color: '#e27b58'
  },
  {
    id: 'jupiter',
    name: 'Jupiter',
    type: 'planet',
    description: 'The largest planet in the Solar System, double the mass of all others combined.',
    details: {
      mass: '1.898 × 10^27 kg',
      diameter: '139,820 km',
      distanceFromSun: '778.5 million km',
      rotationPeriod: '9.9 hours',
      orbitalPeriod: '11.9 years',
      temperature: '-110°C',
      moons: 79,
      funFacts: [
        'The Great Red Spot is a giant storm that has raged for centuries.',
        'Jupiter is a gas giant and doesn’t have a solid surface.',
        'It has the shortest day of all the planets.'
      ]
    },
    image: 'https://upload.wikimedia.org/wikipedia/commons/e/e2/Jupiter.jpg',
    color: '#d39c7e'
  },
  {
    id: 'saturn',
    name: 'Saturn',
    type: 'planet',
    description: 'Famous for its spectacular ring system, Saturn is a gas giant.',
    details: {
      mass: '5.683 × 10^26 kg',
      diameter: '116,460 km',
      distanceFromSun: '1.4 billion km',
      rotationPeriod: '10.7 hours',
      orbitalPeriod: '29.5 years',
      temperature: '-178°C',
      moons: 82,
      funFacts: [
        'Saturn’s rings are made of chunks of ice and rock.',
        'It is the least dense planet—it could float in water.',
        'Its moon Titan is the only moon with a thick atmosphere.'
      ]
    },
    image: 'https://upload.wikimedia.org/wikipedia/commons/c/c7/Saturn_during_Equinox.jpg',
    color: '#c5ab6d'
  },
  {
    id: 'uranus',
    name: 'Uranus',
    type: 'planet',
    description: 'An "ice giant" that rotates on its side.',
    details: {
      mass: '8.681 × 10^25 kg',
      diameter: '50,724 km',
      distanceFromSun: '2.9 billion km',
      rotationPeriod: '17.2 hours',
      orbitalPeriod: '84 years',
      temperature: '-224°C',
      moons: 27,
      funFacts: [
        'Uranus is the coldest planet in the Solar System.',
        'It orbits the sun on its side, like a rolling ball.',
        'It was the first planet discovered with a telescope.'
      ]
    },
    image: 'https://upload.wikimedia.org/wikipedia/commons/3/3d/Uranus2.jpg',
    color: '#bbe1e4'
  },
  {
    id: 'neptune',
    name: 'Neptune',
    type: 'planet',
    description: 'The most distant planet, known for its deep blue color and supersonic winds.',
    details: {
      mass: '1.024 × 10^26 kg',
      diameter: '49,244 km',
      distanceFromSun: '4.5 billion km',
      rotationPeriod: '16.1 hours',
      orbitalPeriod: '164.8 years',
      temperature: '-214°C',
      moons: 14,
      funFacts: [
        'Neptune has the strongest winds in the Solar System.',
        'It takes 165 Earth years to orbit the Sun once.',
        'It has a "Great Dark Spot" similar to Jupiter’s Red Spot.'
      ]
    },
    image: 'https://upload.wikimedia.org/wikipedia/commons/5/56/Neptune_Full.jpg',
    color: '#6081ff'
  },
  {
    id: 'milkyway',
    name: 'Milky Way',
    type: 'galaxy',
    description: 'Our home galaxy, a barred spiral containing 100–400 billion stars.',
    details: {
      mass: '1.5 trillion solar masses',
      diameter: '100,000–200,000 light-years',
      rotationPeriod: '240 million years',
      temperature: 'Varies',
      funFacts: [
        'The Milky Way is part of the Local Group of galaxies.',
        'At its center lies a supermassive black hole, Sagittarius A*.',
        'It is moving towards the Andromeda Galaxy and will collide in 4 billion years.'
      ]
    },
    image: 'https://images.unsplash.com/photo-1534796636912-3b95b3ab5986?auto=format&fit=crop&q=80&w=800',
    color: '#9b59b6'
  },
  {
    id: 'proxima-b',
    name: 'Proxima Centauri b',
    type: 'discovered',
    description: 'A rocky exoplanet orbiting within the habitable zone of our closest stellar neighbor, Proxima Centauri.',
    details: {
      mass: '1.27 Earth masses',
      diameter: '1.1 Earth diameters',
      distanceFromSun: '4.24 light-years',
      rotationPeriod: 'Tidally Locked',
      orbitalPeriod: '11.2 days',
      temperature: '-39°C',
      funFacts: [
        'It is the closest known exoplanet to our solar system.',
        'One side of the planet likely faces its star eternally.',
        'It orbits a red dwarf star much smaller and cooler than our Sun.'
      ]
    },
    image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/f3/Artist%E2%80%99s_impression_of_Proxima_Centauri_b_around_the_red_dwarf_star_Proxima_Centauri.jpg/1200px-Artist%E2%80%99s_impression_of_Proxima_Centauri_b_around_the_red_dwarf_star_Proxima_Centauri.jpg',
    color: '#9e4a3e'
  },
  {
    id: 'kepler-186f',
    name: 'Kepler-186f',
    type: 'discovered',
    description: 'The first Earth-sized planet found in the habitable zone of another star, often called "Earth\'s cousin."',
    details: {
      mass: 'Unknown',
      diameter: '1.1 Earth diameters',
      distanceFromSun: '490 light-years',
      rotationPeriod: 'Unknown',
      orbitalPeriod: '130 days',
      temperature: '-85°C',
      funFacts: [
        'It resides in the Cygnus constellation.',
        'Its star, Kepler-186, is about half the size of our Sun.',
        'It receives about one-third as much sunlight as Earth.'
      ]
    },
    image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Kepler-186f_artist_concept.jpg/1024px-Kepler-186f_artist_concept.jpg',
    color: '#c08e51'
  },
  {
    id: 'trappist-1e',
    name: 'TRAPPIST-1e',
    type: 'discovered',
    description: 'An Earth-sized exoplanet orbiting in the habitable zone of the ultra-cool dwarf star TRAPPIST-1.',
    details: {
      mass: '0.77 Earth masses',
      diameter: '0.91 Earth diameters',
      distanceFromSun: '39 light-years',
      rotationPeriod: 'Tidally Locked',
      orbitalPeriod: '6.1 days',
      temperature: '-22°C',
      funFacts: [
        'One of seven Siblings orbiting the same star.',
        'Considered one of the most likely candidates for liquid surface water.',
        'From its surface, other planets would appear larger than our Moon.'
      ]
    },
    image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Artist%27s_view_of_the_TRAPPIST-1_planetary_system.jpg/1024px-Artist%27s_view_of_the_TRAPPIST-1_planetary_system.jpg',
    color: '#4285f4'
  },
  {
    id: 'hd-189733-b',
    name: 'HD 189733 b',
    type: 'discovered',
    description: 'A "Hot Jupiter" famous for its deep cobalt blue color and hellish weather conditions.',
    details: {
      mass: '1.13 Jupiter masses',
      diameter: '1.13 Jupiter diameters',
      distanceFromSun: '64 light-years',
      rotationPeriod: '2.2 days',
      orbitalPeriod: '2.2 days',
      temperature: '930°C',
      funFacts: [
        'It rains molten glass, blowing sideways in 4,500 mph winds.',
        'The blue color comes from silicate particles scattering light.',
        'It orbits its star so closely that a year lasts only 2 days.'
      ]
    },
    image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a4/Artist_impression_of_HD_189733b.jpg/1200px-Artist_impression_of_HD_189733b.jpg',
    color: '#0047ab'
  },
  {
    id: 'wasp-12b',
    name: 'WASP-12b',
    type: 'discovered',
    description: 'A "doomed" gas giant that is being stretched into an egg shape by its host star.',
    details: {
      mass: '1.4 Jupiter masses',
      diameter: '1.9 Jupiter diameters',
      distanceFromSun: '800 light-years',
      rotationPeriod: '1.1 days',
      orbitalPeriod: '1.1 days',
      temperature: '2,200°C',
      funFacts: [
        'Its atmosphere is being stripped away and devoured by its star.',
        'It is one of the hottest known exoplanets.',
        'In about 10 million years, it will be completely consumed.'
      ]
    },
    image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/07/Artist%27s_conception_of_WASP-12b.jpg/1024px-Artist%27s_conception_of_WASP-12b.jpg',
    color: '#cf7c4a'
  },
  {
    id: '55-cancri-e',
    name: '55 Cancri e',
    type: 'discovered',
    description: 'A super-Earth exoplanet so hot and dense it is thought to be composed largely of diamond.',
    details: {
      mass: '8.6 Earth masses',
      diameter: '1.9 Earth diameters',
      distanceFromSun: '41 light-years',
      rotationPeriod: '0.7 days',
      orbitalPeriod: '0.7 days',
      temperature: '2,400°C',
      funFacts: [
        'One-third of its mass could be pure diamond.',
        'It orbits so close that it might have a permanent ocean of magma.',
        'A year on this planet lasts only 18 hours.'
      ]
    },
    image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/15/Digital_artist%27s_concept_of_an_exoplanet_-_super-Earth_55_Cancri_e.jpg/1024px-Digital_artist%27s_concept_of_an_exoplanet_-_super-Earth_55_Cancri_e.jpg',
    color: '#607d8b'
  },
  {
    id: 'k2-18b',
    name: 'K2-18b',
    type: 'discovered',
    description: 'A "Hycean" world orbiting a red dwarf, notably the first exoplanet in the habitable zone where water vapor was detected.',
    details: {
      mass: '8.6 Earth masses',
      diameter: '2.6 Earth diameters',
      distanceFromSun: '124 light-years',
      rotationPeriod: 'Unknown',
      orbitalPeriod: '33 days',
      temperature: '-73°C to 47°C',
      funFacts: [
        'James Webb Space Telescope detected carbon-bearing molecules in its atmosphere.',
        'It might be a "Hycean" planet - covered in hydrogen and oceans.',
        'It orbits in the habitable zone of its star.'
      ]
    },
    image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c9/Exoplanet_K2-18b_%28artist%E2%80%99s_impression%29.jpg/1200px-Exoplanet_K2-18b_%28artist%E2%80%99s_impression%29.jpg',
    color: '#2e5a88'
  },
  {
    id: 'gliese-581c',
    name: 'Gliese 581c',
    type: 'discovered',
    description: 'One of the first potentially habitable Earth-like planets discovered, orbiting the red dwarf Gliese 581.',
    details: {
      mass: '5.5 Earth masses',
      diameter: '1.5 Earth diameters',
      distanceFromSun: '20 light-years',
      rotationPeriod: 'Tidally Locked',
      orbitalPeriod: '13 days',
      temperature: '0°C to 40°C',
      funFacts: [
        'It was one of the first "Super-Earths" found in a habitable zone.',
        'Because it is tidally locked, there is a "twilight zone" between day and night side.',
        'A message from Earth called "A Message from Earth" was sent there in 2008.'
      ]
    },
    image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/41/Exoplanet_Gliese_581_c_%28artist_impression%29.jpg/1200px-Exoplanet_Gliese_581_c_%28artist_impression%29.jpg',
    color: '#8c4e4e'
  }
];
